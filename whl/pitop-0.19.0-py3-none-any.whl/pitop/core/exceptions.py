class UnavailableComponent(Exception):
    pass


class UninitializedComponent(Exception):
    pass
