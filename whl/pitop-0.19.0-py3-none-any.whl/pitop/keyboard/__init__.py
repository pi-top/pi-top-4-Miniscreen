from .keyboard_button import KeyboardButton

# Deprecated
from .keyboard_button import KeyboardButton as KeyPressListener
