from enum import IntEnum


class CameraTypes(IntEnum):
    USB_CAMERA = 0
    FILE_SYSTEM_CAMERA = 1
